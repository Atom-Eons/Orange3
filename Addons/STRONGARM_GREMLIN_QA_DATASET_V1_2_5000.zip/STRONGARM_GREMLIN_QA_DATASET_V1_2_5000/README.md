# STRONGARM Gremlin Q&A Dataset v1.2 — 5,000 Pairs

This is the expanded starter dataset.

It includes the original 2,000 Gremlin packet pairs plus **3,000 new vibe-axis pairs** built from:

```text
Goonies crew-energy      → crew loyalty, treasure-map thinking, underdog movement
Mamba excellence         → reps, film-room correction, no soft finish
Indiana field intelligence → map, clue, artifact, field verification
Picard command judgement → calm authority, visible decision chain
Nonstop go-hard execution → ship, verify, improve, next action now
```

These are encoded as **traits**, not imitation/cosplay.

## Files

```text
data/gremlin_qa_5000_combined.jsonl       full 5,000-row combined dataset
data/gremlin_qa_3000_addon_vibes.jsonl    only the new 3,000 rows
data/train.jsonl                          4,250 rows
data/val.jsonl                            375 rows
data/test.jsonl                           375 rows
data/gremlin_qa_5000_combined.csv         human-readable full review
data/gremlin_qa_3000_addon_vibes.csv      human-readable addon review
data/dataset_stats.json
schemas/gremlin_packet.schema.json
prompts/gremlin_system_prompt.txt
scripts/validate_dataset.py
scripts/sample_dataset.py
```

## Combined distribution

```json
{
  "attack": 2250,
  "calm": 1000,
  "alert": 1750
}
```

Decision distribution:

```json
{
  "block": 500,
  "support": 1000,
  "revise": 3500
}
```

Influence axis distribution:

```json
{
  "indiana_field": 682,
  "nonstop_gohard": 576,
  "base": 2000,
  "mamba": 609,
  "picard_command": 576,
  "goonies_crew": 557
}
```

## Validate

```bash
python scripts/validate_dataset.py
```

## Sample

```bash
python scripts/sample_dataset.py data/gremlin_qa_5000_combined.jsonl 10
python scripts/sample_dataset.py data/gremlin_qa_5000_combined.jsonl 10 mamba
```

## Doctrine

```text
Gremlin pressures.
Mirror verifies.
STRONGARM disciplines.
JUDGEMENT decides.
Operator rules.
Receipts prove.
```
