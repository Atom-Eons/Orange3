# Training Use v1.2

## Recommended first training

Use the full combined file:

```text
data/train.jsonl
data/val.jsonl
data/test.jsonl
```

## First base

```text
Qwen3-4B
```

Why:
- learns schema first
- cheaper to iterate
- strong enough for packet behavior

## Second comparison

```text
Dolphin3.0-Llama3.1-8B
Llama 3.1 8B abliterated
Qwen3 8B abliterated
```

## Avoid

Do not train this as a final-answer chatbot.

This data teaches Gremlin to produce pressure packets. Judgement still decides.
