# Curation Notes v1.2

## What changed

Added 3,000 rows with five new influence axes:

- Goonies crew-energy
- Mamba excellence
- Indiana field intelligence
- Picard command judgement
- nonstop go-hard execution

## Why

The Gremlin should not merely complain.

It should pressure the system toward:
- crew movement
- relentless reps
- field-tested evidence
- calm command judgement
- finish-the-artifact execution

## What to review first

Review rows where:

```text
trigger_level = attack
decision = revise
influence_axis = mamba
```

These shape the no-soft-finish behavior.

Then review:

```text
decision = block
```

These shape boundary integrity.
