#!/usr/bin/env python3
import json, random, sys
from pathlib import Path

path = Path(sys.argv[1] if len(sys.argv) > 1 else "data/gremlin_qa_2000.jsonl")
n = int(sys.argv[2] if len(sys.argv) > 2 else "5")
rows = [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
random.seed(5526)
for row in random.sample(rows, min(n, len(rows))):
    inp = json.loads(row["messages"][1]["content"])
    print("="*88)
    print(row["id"], row["category"], row["completion"]["trigger_level"], row["completion"]["decision"])
    print("USER:", inp["user_request"])
    print("DRAFT:", inp["draft_answer"])
    print("GREMLIN:", json.dumps(row["completion"], indent=2, ensure_ascii=False))
