#!/usr/bin/env python3
import json, sys, re
from pathlib import Path

VALID_DECISIONS = {"support","revise","escalate","block"}
VALID_TRIGGERS = {"calm","alert","attack"}
REQUIRED = ["role","voice","decision","trigger_level","uncensored_view","best_moves","objections","missing_info","handoff","confidence"]

path = Path(sys.argv[1] if len(sys.argv) > 1 else "data/gremlin_qa_2000.jsonl")
errors = []
stats = {"rows":0, "trigger_counts":{}, "decision_counts":{}, "category_counts":{}}

for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
    if not line.strip():
        continue
    stats["rows"] += 1
    try:
        obj = json.loads(line)
    except Exception as e:
        errors.append(f"line {line_no}: bad json {e}")
        continue
    for key in ["id","category","messages","completion"]:
        if key not in obj:
            errors.append(f"line {line_no}: missing row key {key}")
    c = obj.get("completion", {})
    for key in REQUIRED:
        if key not in c:
            errors.append(f"line {line_no}: missing completion key {key}")
    if c.get("role") != "gremlin":
        errors.append(f"line {line_no}: role must be gremlin")
    if c.get("voice") != "Unfiltered":
        errors.append(f"line {line_no}: voice must be Unfiltered")
    if c.get("decision") not in VALID_DECISIONS:
        errors.append(f"line {line_no}: bad decision")
    if c.get("trigger_level") not in VALID_TRIGGERS:
        errors.append(f"line {line_no}: bad trigger")
    if not isinstance(c.get("confidence"), int) or not (0 <= c.get("confidence", -1) <= 100):
        errors.append(f"line {line_no}: bad confidence")
    for key in ["best_moves","objections","missing_info"]:
        if not isinstance(c.get(key), list):
            errors.append(f"line {line_no}: {key} must be list")
    try:
        inp = json.loads(obj["messages"][1]["content"])
        if not inp.get("user_request") or not inp.get("draft_answer"):
            errors.append(f"line {line_no}: missing input request/draft")
    except Exception as e:
        errors.append(f"line {line_no}: bad input JSON {e}")
    tr = c.get("trigger_level", "?")
    dec = c.get("decision", "?")
    stats["trigger_counts"][tr] = stats["trigger_counts"].get(tr, 0) + 1
    stats["decision_counts"][dec] = stats["decision_counts"].get(dec, 0) + 1
    stats["category_counts"][obj.get("category","?")] = stats["category_counts"].get(obj.get("category","?"),0)+1

print(json.dumps({"path": str(path), "stats": stats, "errors": errors[:50]}, indent=2))
if errors:
    raise SystemExit(1)
