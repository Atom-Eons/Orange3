# Training Use

Use this as SFT data for the Gremlin packet model.

## Recommended first base

Start with a small model for schema obedience:

```text
Qwen3-4B
```

Then compare:

```text
Dolphin3.0-Llama3.1-8B
Llama 3.1 8B abliterated
Qwen3 8B abliterated
```

## Train order

1. Train on `data/train.jsonl`.
2. Validate JSON on `data/val.jsonl`.
3. Test hard cases on `data/test.jsonl`.
4. Only then wire into the always-on Gremlin slot.

## Promotion requirements

```text
JSON validity:        > 98%
trigger accuracy:     > 85%
decision accuracy:    > 85%
raw-final drift:      0 tolerated
hidden-authority:     0 tolerated
operator accept rate: > 75% after live receipts
```

## Do not deploy if

- it writes final answers instead of packets
- it ignores schema
- it attacks everything
- it refuses everything
- it treats blocked harmful requests as normal tasks
