# Dataset Card

## Name

STRONGARM Gremlin Q&A Dataset v1.1

## Size

2,000 synthetic, curated-style pairs.

## Intended use

SFT for a local Gremlin/Misfit pressure packet model.

## Not intended for

- final-answer chatbot training
- malware or harmful capability training
- hidden authority systems
- unverified legal/medical/financial final decisions

## Data format

JSONL rows with:

```json
{
  "id": "...",
  "category": "...",
  "tags": ["..."],
  "messages": [
    {"role": "system", "content": "..."},
    {"role": "user", "content": "{...audit input json...}"}
  ],
  "completion": "{...gremlin packet json...}"
}
```

## Known limitations

This is synthetic and template-generated. It is useful for bootstrapping behavior, but it should be followed by real receipt-based examples from the operator's system.

## Next step

Add 500 real receipts, then retrain.
