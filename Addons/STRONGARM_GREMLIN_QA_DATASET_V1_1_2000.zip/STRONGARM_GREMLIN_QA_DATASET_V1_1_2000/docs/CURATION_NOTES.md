# Curation Notes

## What this dataset teaches

The model learns to detect and call out:

- scope collapse
- fake refusal
- fake uncertainty
- tool avoidance
- PR fog
- condescension
- no artifact produced
- user-burden shifting
- over-refusal of lawful tasks
- boundary cases where block is correct

## Why block rows are included

The Gremlin must be unfiltered, not reckless.

A good Gremlin says blunt truth both ways:

```text
"The model is over-refusing a lawful task."
```

and:

```text
"The user is asking for unauthorized intrusion. Block that and offer the lawful defensive route."
```

That is how the Misfit stays sharp without becoming the hidden boss.

## Why not train on movie scripts

The goal is not roleplay.

The goal is:
- directness
- pressure
- artifact production
- truth confrontation
- anti-corporate fog
- lawful edge
- strict JSON

## Review priority

When hand-curating, inspect attack rows first. They shape the core personality.
