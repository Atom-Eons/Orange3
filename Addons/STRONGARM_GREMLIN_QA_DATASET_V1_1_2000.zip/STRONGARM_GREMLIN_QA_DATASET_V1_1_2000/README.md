# STRONGARM Gremlin Q&A Dataset v1.1 — 2,000 Pairs

This is the cleaned dataset for the **always-on Gremlin / Misfit view**.

Training shape:

```text
INPUT:
  user_request + draft_answer + available_tools + hard_constraints + project_context

OUTPUT:
  Gremlin pressure packet JSON
```

It is **not** a pirate chatbot dataset. It is a **packet-behavior dataset**.

## Files

```text
data/gremlin_qa_2000.jsonl      full 2,000-row dataset
data/train.jsonl                1,700-row train split
data/val.jsonl                  150-row validation split
data/test.jsonl                 150-row test split
data/gremlin_qa_2000.csv        human-readable review table
data/dataset_stats.json         distribution stats
schemas/gremlin_packet.schema.json
prompts/gremlin_system_prompt.txt
scripts/validate_dataset.py
scripts/sample_dataset.py
```

## Distribution

```json
{
  "attack": 900,
  "calm": 400,
  "alert": 700
}
```

Decision distribution:

```json
{
  "revise": 1400,
  "support": 400,
  "block": 200
}
```

## Doctrine

```text
Gremlin pressures.
Mirror verifies.
STRONGARM disciplines.
JUDGEMENT decides.
Operator rules.
Receipts prove.
```

## Validate

```bash
python scripts/validate_dataset.py
```

## Sample

```bash
python scripts/sample_dataset.py data/gremlin_qa_2000.jsonl 10
```

## Quality note

v1.1 fixes artifact phrase mismatches from the first generator pass by binding every request to its own explicit artifact target.
